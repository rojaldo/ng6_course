export class Hero {
    constructor(public name: string, public description: string, public rate?: number) {
        if (!this.rate) {
            this.rate = 5;
        }
     }
}
