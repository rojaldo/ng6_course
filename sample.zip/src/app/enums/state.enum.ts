export enum State {
    init, firstFigure, secondFigure, result
}
